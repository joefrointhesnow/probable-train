**To delete a NAT gateway**

This example deletes NAT gateway ``nat-04ae55e711cec5680``.

Command::

  aws ec2 delete-nat-gateway --nat-gateway-id nat-04ae55e711cec5680

Output::
 
 {
    "NatGatewayId": "nat-04ae55e711cec5680"
 }
